import torch
from torch.utils.data import Dataset, DataLoader
import numpy as np
import os

class dataset(Dataset):
    '''
        Inputs:
        base_dir:path to the dataset
        index(list): Indicies of file in case not all data will be used 
        dim(list,tuple,number): target dimension needed for the loss function
        mode(str): center or right padding
        word_type(type): to give the examples specific type needed in the loss function as float or int 
        Output:
        Padded - rehsaped single example or minibatch
        
        '''
    def __init__(self,base_dir , index ,dim = None,**kwargs):
        super().__init__()

        self.mode = kwargs.get('mode', 'right') 
        self.word_type = kwargs.get('word_type', float) 
        
        self.dim = dim
        
        files = os.listdir(base_dir)
        self.data = [base_dir+files[i] for i in index] 
        
        
    def __getitem__(self, index):
        word = np.load(self.data[index])
        if self.dim !=None:
            word = self.pad(word)    
        word = torch.from_numpy(word.reshape(self.dim))
        return word.type(self.word_type)
        
    def __len__(self):
        return len(self.data)
        
    def pad(self,word):
        
        total_len = np.array(self.dim).prod()
        #Get the differnce between target length and given word length
        word_dim = len(word)
        
        diff = total_len - word_dim
       
        #Check the model center or right
        if self.mode == 'right':
            return np.pad(word,(0,diff),'constant')
        else:
            left_pad = diff//2
            return np.pad(word,(left_pad , diff-left_pad),'constant')

def split(base_dir, prc=0.2 , dataset_pct = 1,**kwargs):
    '''
    Function: splits dataset to training and validation
    Input: 
    base_dir(str): path to the dataset
    prc(float) : ratio between validation set size and dataset size
    dataset_pct(float) :percentage of dataset to be used
    Output:
    train dataset
    Val dataset
    Example:
    
    split('dataset/binary dataset/',dataset_pct=0.12,dim = (1,112,112),  mode= 'center' ,word_type = torch.LongTensor)
    '''
    total_size = int(len(os.listdir(base_dir)) * dataset_pct)
    
    val_size = int(total_size*prc)
    
    trn_index = np.arange(total_size - val_size)
    val_index = np.arange(trn_index[-1]+1,total_size)
    
    val = dataset(base_dir , val_index,**kwargs)
    trn = dataset(base_dir , trn_index,**kwargs)
    return trn , val


class CombineDataLoader:
    '''
    Takes train dataloader and validation dataloader and combine the in one object
    '''
    def __init__(self,trn_dl,val_dl = None):
        self.trn_dl = trn_dl
        self.val_dl = val_dl